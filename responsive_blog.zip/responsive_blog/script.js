document.getElementById('dark-mode').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
});

document.querySelectorAll('.read_more').forEach(function(button) {
    button.addEventListener('click', function() {
        var fullContent = this.previousElementSibling;
        fullContent.classList.toggle('hidden');
        if (fullContent.classList.contains('hidden')) {
            this.textContent = 'Read More';
        } else {
            this.textContent = 'Read Less';
        }
    });
});

document.getElementById('comment_form').addEventListener('submit', function(e) {
    e.preventDefault();
    var commentInput = document.getElementById('comment_input');
    var commentText = commentInput.value;
    if (commentText) {
        var comment = document.createElement('div');
        comment.className = 'comment';
        comment.textContent = commentText;
        document.getElementById('comments_container').appendChild(comment);
        commentInput.value = '';
    }
});

document.getElementById('clear_comments').addEventListener('click', function() {
    document.getElementById('comments_container').innerHTML = '';
});

